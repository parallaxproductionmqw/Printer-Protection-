package ru.printerguard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PrinterGuard extends JavaPlugin implements Listener {

    private static final int F_TICK = 1;   // несколько блоков за один тик
    private static final int F_REACH = 2;  // слишком далеко
    private static final int F_LOOK = 4;   // игрок смотрит не туда

    private record Flag(long time, int bits) {}

    private static class State {
        final Deque<Flag> flags = new ArrayDeque<>();
        int lastTick = -1;
        long alertTime = 0;
        int confirm = 0;
    }

    private final Map<UUID, State> states = new HashMap<>();

    private int minFlagged;
    private long windowMs;
    private double maxReach;
    private double maxLookAngle;
    private long banWindowMs;
    private int confirmFlagged;
    private String adminMessage;
    private String banNotifyMessage;
    private String banCommand;
    private double minTps;
    private int maxPing;
    private boolean cancelPlacement;
    private boolean ignoreCreative;
    private boolean debug;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    private void loadSettings() {
        reloadConfig();
        minFlagged = getConfig().getInt("min-flagged", 5);
        windowMs = getConfig().getLong("window-ms", 2000);
        maxReach = getConfig().getDouble("max-reach", 6.0);
        maxLookAngle = getConfig().getDouble("max-look-angle", 30.0);
        banWindowMs = (long) (getConfig().getDouble("ban-window-seconds", 3) * 1000L);
        confirmFlagged = Math.max(1, getConfig().getInt("confirm-flagged", 3));
        adminMessage = getConfig().getString("admin-message",
                "&c[PrinterGuard] &fИгрок %player% использует принтер!");
        banNotifyMessage = getConfig().getString("ban-notify-message",
                "&c[PrinterGuard] &fИгрок %player% забанен.");
        banCommand = getConfig().getString("ban-command", "tempban %player% 1d Printer");
        minTps = getConfig().getDouble("min-tps", 18.0);
        maxPing = getConfig().getInt("max-ping", 400);
        cancelPlacement = getConfig().getBoolean("cancel-placement", true);
        ignoreCreative = getConfig().getBoolean("ignore-creative", false);
        debug = getConfig().getBoolean("debug", false);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (p.hasPermission("printerguard.bypass")) return;
        if (ignoreCreative && p.getGameMode() == GameMode.CREATIVE) return;

        State st = states.computeIfAbsent(p.getUniqueId(), k -> new State());
        int tick = Bukkit.getCurrentTick();
        int prevTick = st.lastTick;
        st.lastTick = tick;

        // защита от ложных срабатываний: лаги сервера / высокий пинг игрока
        if (Bukkit.getTPS()[0] < minTps || p.getPing() > maxPing) {
            st.flags.clear();
            return;
        }

        // --- признаки принтера ---
        int bits = 0;
        if (prevTick == tick) bits |= F_TICK;

        Location eye = p.getEyeLocation();
        Vector toBlock = e.getBlockAgainst().getLocation().add(0.5, 0.5, 0.5)
                .toVector().subtract(eye.toVector());
        double dist = toBlock.length();
        double angle = 0;
        if (dist > maxReach) bits |= F_REACH;
        if (dist >= 2.0) {
            angle = Math.toDegrees(eye.getDirection().angle(toBlock));
            if (angle > maxLookAngle) bits |= F_LOOK;
        }

        if (bits == 0) return; // обычная установка или EasyPlace - игнорируем

        if (debug) {
            getLogger().info(String.format("[debug] %s: флаги=%s расстояние=%.1f угол=%.0f",
                    p.getName(), describe(bits), dist, angle));
        }

        long now = System.currentTimeMillis();

        // идёт фаза после предупреждения: ждём продолжения -> бан
        if (st.alertTime != 0) {
            if (now - st.alertTime <= banWindowMs) {
                if (cancelPlacement) e.setCancelled(true);
                st.confirm++;
                if (st.confirm >= confirmFlagged) {
                    st.alertTime = 0;
                    st.confirm = 0;
                    st.flags.clear();
                    notifyAdmins(fill(banNotifyMessage, p, 0, ""));
                    getLogger().warning(p.getName() + " -> BAN: продолжил использовать принтер");
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                            banCommand.replace("%player%", p.getName()));
                }
                return;
            }
            // окно истекло - начинаем заново
            st.alertTime = 0;
            st.confirm = 0;
        }

        st.flags.addLast(new Flag(now, bits));
        while (!st.flags.isEmpty() && now - st.flags.peekFirst().time() > windowMs) {
            st.flags.removeFirst();
        }

        if (st.flags.size() < minFlagged) return;

        int count = st.flags.size();
        String reasons = reasons(st.flags);
        st.flags.clear();
        st.alertTime = now;
        st.confirm = 0;
        if (cancelPlacement) e.setCancelled(true);

        notifyAdmins(fill(adminMessage, p, count, reasons));
        getLogger().warning(p.getName() + " -> ALERT: использует принтер, подозрительных блоков "
                + count + " (" + reasons + ")");
    }

    private String describe(int bits) {
        StringBuilder sb = new StringBuilder();
        if ((bits & F_TICK) != 0) sb.append("за-тик ");
        if ((bits & F_REACH) != 0) sb.append("далеко ");
        if ((bits & F_LOOK) != 0) sb.append("не-смотрит ");
        return sb.toString().trim();
    }

    private String reasons(Deque<Flag> flags) {
        int t = 0, r = 0, l = 0;
        for (Flag f : flags) {
            if ((f.bits() & F_TICK) != 0) t++;
            if ((f.bits() & F_REACH) != 0) r++;
            if ((f.bits() & F_LOOK) != 0) l++;
        }
        return "несколько за тик: " + t + ", далеко: " + r + ", не смотрит на блок: " + l;
    }

    private String fill(String template, Player p, int count, String reasons) {
        return template
                .replace("%player%", p.getName())
                .replace("%count%", String.valueOf(count))
                .replace("%reasons%", reasons)
                .replace("%ban_window%", String.valueOf(banWindowMs / 1000.0).replaceAll("\\.0$", ""));
    }

    private void notifyAdmins(String msg) {
        Component c = LegacyComponentSerializer.legacyAmpersand().deserialize(msg);
        for (Player op : Bukkit.getOnlinePlayers()) {
            if (op.hasPermission("printerguard.notify")) {
                op.sendMessage(c);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("printerguard.admin")) return true;
        if (a.length > 0 && a[0].equalsIgnoreCase("reload")) {
            loadSettings();
            s.sendMessage("PrinterGuard: конфиг перезагружен");
        } else {
            s.sendMessage("/printerguard reload");
        }
        return true;
    }
}
